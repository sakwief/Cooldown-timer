package dev.cooldowntimer.mixin;

import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DrawContext.class)
public abstract class DrawContextMixin {

    @Inject(
        method = "drawStackOverlay(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V",
        at = @At("TAIL")
    )
    private void cdt$drawCooldownTime(TextRenderer tr, ItemStack stack, int x, int y, String countOverride, CallbackInfo ci) {
        if (stack.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        ItemCooldownManager cm = mc.player.getItemCooldownManager();
        if (!cm.isCoolingDown(stack)) return;

        ItemCooldownManagerAccessor acc = (ItemCooldownManagerAccessor) (Object) cm;
        Identifier group = cm.getGroup(stack);
        Object entry = acc.cdt$getEntries().get(group);
        if (entry == null) return;

        int remainingTicks = ((CooldownEntryAccessor) entry).cdt$getEndTick() - acc.cdt$getTick();
        if (remainingTicks <= 0) return;

        double sec = remainingTicks / 20.0;
        String text;
        if (sec >= 60) text = (int) (sec / 60) + "m";
        else if (sec >= 10) text = Integer.toString((int) Math.ceil(sec));
        else text = String.format(Locale.ROOT, "%.1f", sec);

        float scale = 0.6f;
        float w = tr.getWidth(text) * scale;
        DrawContext self = (DrawContext) (Object) this;
        self.getMatrices().pushMatrix();
        self.getMatrices().translate(x + 17 - w, y + 1);
        self.getMatrices().scale(scale, scale);
        self.drawText(tr, text, 0, 0, 0xFFFFFFFF, true);
        self.getMatrices().popMatrix();
    }
}
